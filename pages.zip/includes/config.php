<?php
// Konfigurasi database
$host = "localhost";       // atau IP server database
$dbname = "dbkamus";       // nama database kamu
$user = "root";            // user MySQL
$pass = "";                // password MySQL (kosong kalau default di XAMPP)

// Set timezone
date_default_timezone_set("Asia/Jakarta");

try {
    // Buat koneksi PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}
